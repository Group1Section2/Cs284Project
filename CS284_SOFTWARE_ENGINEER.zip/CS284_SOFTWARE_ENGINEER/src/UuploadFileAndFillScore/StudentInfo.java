package UuploadFileAndFillScore;

import java.util.ArrayList;

public class StudentInfo {
	private String name;
	private String grade;
	
	private long id;
	private int index;

	private ArrayList<Score> score;
	
	public StudentInfo(int index, long id, String name) {
		this.name = name;
		this.grade = "";
		
		this.id = id;
		this.index = index;
		
		this.score = new ArrayList<>();
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getName() {
		return name;
	}

	public ArrayList<Score> getScore() {
		return score;
	}

	public long getId() {
		return id;
	}

	public int getIndex() {
		return index;
	}

	
	
	public void addScore(String exam,double max,double weight){
		this.score.add(new Score(exam,max,weight));
		
	}
	public void removeScore(String exam){
		for(int i=0;i<score.size();i++){
			if(score.get(i).getExam().contentEquals(exam)){
				score.remove(i);
			}
		}
	
	}
	public boolean examContain(String exam){
		boolean contain = false;
		for(Score s : score){
			if(s.getExam().contentEquals(exam)){
				contain = true;
			}
		}
		
		return contain;
	}
	public double getMax(String exam){
		for(Score s : score){
			if(s.getExam().contentEquals(exam)){
				return s.getMaxScore();
			}
		}
		return 0.0;
	}
	public void updateScore(String exam,double score){
		for(Score s: this.score){
			if(s.getExam().contentEquals(exam)){
				s.setScore(score);
			}
		}
	}
	public void setNetScore(String exam,double netScore){
		for(Score s: this.score){
			if(s.getExam().contentEquals(exam)){
				s.setNetScore(netScore);
			}
		}
	}
	public double getParameter(String exam){
		for(Score s : score){
			if(s.getExam().contentEquals(exam)){
				return s.getWeight()/s.getMaxScore();
			}
		}
		return 0.0;
	}
	public double getNetScore(String exam){
		for(Score s : score){
			if(s.getExam().contentEquals(exam)){
				return s.getNetScore();
			}
		}
		return 0.0;
	}
	public double getScore(String exam){
		for(Score s : score){
			if(s.getExam().contentEquals(exam)){
				return s.getScore();
			}
		}
		return 0.0;
	}
	public double getGradeScore(){
		double max = 0;
		double get = 0;
		
		for(Score s: score){
			max+= s.getWeight();
			get+= s.getNetScore();
		}
		return (get/max)*100;
	}
	
//	public void print(){
//		System.out.print(index+" "+name+" "+id+" ");
//		for(Score s:score){
//			System.out.print(s.getExam()+" "+s.getMaxScore()+" "+/*s.getWeight()+" "+*/s.getScore()+" "+s.getNetScore());
//		}
//		System.out.println();
//		
//	}

	
	
}
