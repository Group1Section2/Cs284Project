package UuploadFileAndFillScore;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class ScoreManager implements CalculateScore {
	ArrayList<Double> list;
	
	public ScoreManager(){
		list = new ArrayList<>();
	}
	public boolean setScore(double score,double maxScore) {
		boolean check = false;
		if (score < 0) {
			check = false;
		} else if (score > maxScore) {
			check = false;
		} else {
			check = true;
		}
		return check;
	}
	public double calculateScore(double score,double parameter) {
		return score*parameter;
	}
	public void setGradeList(ArrayList<Double> gradeList){
		list = gradeList;
	}
	@Override
	public String gradeCalculate(double gradeScore) {
		if(list==null){
			return null;
		}else if(gradeScore>=list.get(0)){
			return "A";
		}else if(gradeScore>=list.get(1)){
			return "B+";
		}else if(gradeScore>=list.get(2)){
			return "B";
		}else if(gradeScore>=list.get(3)){
			return "C+";
		}else if(gradeScore>=list.get(4)){
			return "C";
		}else if(gradeScore>=list.get(5)){
			return "D+";
		}else if(gradeScore>=list.get(6)){
			return "D";
		}else{
			return "F";
		}
	}
	public ArrayList<Double> getList() {
		return list;
	}
}
