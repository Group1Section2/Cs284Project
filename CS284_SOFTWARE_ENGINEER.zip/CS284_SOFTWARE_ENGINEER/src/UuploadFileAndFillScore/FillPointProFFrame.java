package UuploadFileAndFillScore;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class FillPointProFFrame extends JFrame {
	private FillPointProFPanel fp;
	public FillPointProFFrame() {
		
		fp = new FillPointProFPanel();
		this.setIconImage((new ImageIcon("icon.png")).getImage());
		this.add(fp);
		this.pack();
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
}
