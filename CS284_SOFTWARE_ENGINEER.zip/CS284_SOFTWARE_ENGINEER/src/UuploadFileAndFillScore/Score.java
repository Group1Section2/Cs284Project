package UuploadFileAndFillScore;

public class Score {
	private String exam;
	private double score;
	private double maxScore;
	private double netScore;
	private double weight;
	
	public Score(String exam,double maxScore,double weight) {
		this.exam = exam;
		this.maxScore = maxScore;
		this.weight = weight;
		
		score = 0.0;
		netScore = 0.0;
	}
	
	public double getMaxScore() {
		return maxScore;
	}

	public double getNetScore() {
		return netScore;
	}

	public double getWeight() {
		return weight;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public String getExam() {
		return exam;
	}

	public void setNetScore(double netScore) {
		this.netScore = netScore;
	}

	public double getScore() {
		return score;
	}
	
}
