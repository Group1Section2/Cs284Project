package UuploadFileAndFillScore;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import UEmail.StudentEmailController;
import Uexcel.WritingExcelMng;

public class FillPointProFPanel extends JPanel {

	private JButton uploadBtn, addBtn, deleteBtn, calculateBtn, saveBtn, exitBtn, sendEmailBtn;
	private JFileChooser jfc;
	private File file;
	private StudentControl stc;
	private JTable studentInfoTable;
	private ArrayList<String> columnName;
	private String[][] rows;
	private JLabel status;
	private ScoreManager scm;
	private StudentEmailController sec;

	public FillPointProFPanel() {

		JPanel controlPanel = new JPanel();
		JPanel tablepanel = new JPanel();
		JPanel btnPanel = new JPanel();
		JPanel statusPanel = new JPanel();
		JPanel contentPane = new JPanel();
		status = new JLabel();

		jfc = new JFileChooser(".");
		stc = new StudentControl();
		sec = new StudentEmailController();
		scm = new ScoreManager();

		columnName = new ArrayList<>();
		columnName.add("Index");
		columnName.add("ID.");
		columnName.add("Name");

		rows = new String[0][3];

		studentInfoTable = new JTable(rows, columnName.toArray());

		JScrollPane tableScroll = new JScrollPane(studentInfoTable);
		tableScroll.setPreferredSize(new Dimension(800, 460));
		tablepanel.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY), "Untitled"));
		tablepanel.add(tableScroll);

		uploadBtn = new JButton(new ImageIcon("upload.jpg"));
		uploadBtn.setPreferredSize(new Dimension(200, 50));
		uploadBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				stc.getData().clear();
				if (jfc.showOpenDialog(null) == jfc.APPROVE_OPTION) {
					if(columnName.size()>3) {
						for (int i = 3; i < columnName.size(); i++) {

							columnName.remove(i);
							
						}
						for (String s : columnName) {
							if (s.equals("Grade Score")) {
								columnName.remove(columnName.indexOf(s));
								break;
							}
						}
						studentInfoTable.setModel(new DefaultTableModel(rows, columnName.toArray()));
					}
					deleteBtn.setEnabled(false);
					calculateBtn.setEnabled(false);
					sendEmailBtn.setEnabled(false);
					saveBtn.setEnabled(false);
					addBtn.setEnabled(true);
					file = jfc.getSelectedFile();
					stc.readFile(file);
					tablepanel.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY), file.getName()));
					rows = new String[stc.getData().size()][columnName.size()];

					for (int i = 0; i < stc.getData().size(); i++) {
						for (int j = 0; j < columnName.size(); j++) {
							if (j == 0) {
								rows[i][j] = stc.getData().get(i).getIndex() + "";
							} else if (j == 1) {
								rows[i][j] = stc.getData().get(i).getId() + "";

							} else if (j == 2) {
								rows[i][j] = stc.getData().get(i).getName();

							}
						}
					}
					studentInfoTable.setModel(new DefaultTableModel(rows, columnName.toArray()));

				}

			}
		});

		addBtn = new JButton(new ImageIcon("Add.jpg"));
		addBtn.setPreferredSize(new Dimension(200, 50));
		addBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String newColumnName = JOptionPane.showInputDialog(null, "Input your column name");
				if (!stc.examContain(newColumnName)) {
					if (newColumnName != null) {
						deleteBtn.setEnabled(true);
						calculateBtn.setEnabled(true);
						columnName.add(newColumnName);
						studentInfoTable.setModel(new DefaultTableModel(rows, columnName.toArray()));

						double max;
						double weight;
						while (true) {
							try {

								do {
									String parameter = JOptionPane.showInputDialog(null,
											"Input your parameter for " + newColumnName + " : max,net");
									StringTokenizer st = new StringTokenizer(parameter, ",");
									max = Double.parseDouble(st.nextToken());
									weight = Double.parseDouble(st.nextToken());
									if (max < weight) {
										JOptionPane.showMessageDialog(null, "max must over than net");
									}
								} while (max < weight);

								for (int i = 0; i < stc.getData().size(); i++) {
									stc.addExam(i, newColumnName, max, weight);

								}
								break;
							} catch (NoSuchElementException e1) {
								JOptionPane.showMessageDialog(null, "Please input max and net");
							} catch (NumberFormatException e2) {
								JOptionPane.showMessageDialog(null, "Please use , to split max and net");
							} catch (NullPointerException e2) {
								JOptionPane.showMessageDialog(null, "you need to fill max and net");
							}
						}

					}
				} else {
					JOptionPane.showMessageDialog(null, "Can't add same exam");
				}
			}
		});

		deleteBtn = new JButton(new ImageIcon("delete.jpg"));
		deleteBtn.setPreferredSize(new Dimension(200, 50));
		deleteBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
			

				try {
					String deleteName = JOptionPane.showInputDialog(null, "Input your delete exam");
					for (int i = 3; i < columnName.size(); i++) {
						if (columnName.get(i).contentEquals(deleteName)) {
							columnName.remove(i);
							for (String s : columnName) {
								if (s.equals("Grade Score")) {
									columnName.remove(columnName.indexOf(s));
									break;
								}
							}
						}
					}

					for (int i = 0; i < stc.getData().size(); i++) {
						stc.removeExam(i, deleteName);
					}
					studentInfoTable.setModel(new DefaultTableModel(rows, columnName.toArray()));
				} catch (NullPointerException e2) {

				}
			}
		});

		calculateBtn = new JButton(new ImageIcon("calculate.jpg"));
		calculateBtn.setPreferredSize(new Dimension(200, 50));
		calculateBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				scm.getList().clear();
				if (scm.getList().isEmpty()) {
					do {
						String gradeListString = JOptionPane.showInputDialog(null, "Score for Grade(A,B+,B,C+,C,D+,D)");
						StringTokenizer list = new StringTokenizer(gradeListString, ",");

						try {
							ArrayList<Double> gradeList = new ArrayList<>();
							gradeList.add(Double.parseDouble(list.nextToken()));
							gradeList.add(Double.parseDouble(list.nextToken()));
							gradeList.add(Double.parseDouble(list.nextToken()));
							gradeList.add(Double.parseDouble(list.nextToken()));
							gradeList.add(Double.parseDouble(list.nextToken()));
							gradeList.add(Double.parseDouble(list.nextToken()));
							gradeList.add(Double.parseDouble(list.nextToken()));
							scm.setGradeList(gradeList);
							break;
						} catch (NoSuchElementException e1) {
							JOptionPane.showMessageDialog(null, "Please complete Grade score");
						} catch (NumberFormatException e2) {
							JOptionPane.showMessageDialog(null, "fill only number");
						}catch (NullPointerException e2) {
							JOptionPane.showMessageDialog(null, "Please use  , in correct way");
						}
					} while (true);
				}
				sendEmailBtn.setEnabled(true);
				saveBtn.setEnabled(true);

				for (int i = 0; i < stc.getData().size(); i++) {
					for (int j = 0; j < columnName.size(); j++) {
						if (stc.examContain(columnName.get(j))) {
							if (studentInfoTable.getValueAt(i, j) == null) {
								studentInfoTable.setValueAt(0.0, i, j);
							} else if (!(scm.setScore(Double.parseDouble(studentInfoTable.getValueAt(i, j).toString()),
									stc.getMax(columnName.get(j))))) {
								studentInfoTable.setValueAt(0.0, i, j);
							}
							stc.updateScore(i, columnName.get(j),
									Double.parseDouble(studentInfoTable.getValueAt(i, j).toString()));
							stc.setNetScore(i, columnName.get(j), scm.calculateScore(stc.getScore(i, columnName.get(j)),
									stc.getParameter(columnName.get(j))));
							stc.setGrade(i, scm.gradeCalculate(stc.getGradeScore(i)));
						}
					}
				}

				for (String s : columnName) {
					if (s.equals("Grade Score")) {
						columnName.remove(columnName.indexOf(s));
						break;
					}
				}
				columnName.add("Grade Score");
				rows = new String[stc.getData().size()][columnName.size()];

				for (int i = 0; i < stc.getData().size(); i++) {
					for (int j = 0; j < columnName.size(); j++) {
						if (j == 0) {
							rows[i][j] = stc.getData().get(i).getIndex() + "";

						} else if (j == 1) {
							rows[i][j] = stc.getData().get(i).getId() + "";

						} else if (j == 2) {
							rows[i][j] = stc.getData().get(i).getName();

						} else if (j == columnName.size() - 1) {
							rows[i][j] = stc.getData().get(i).getGradeScore() + "";
						} else {
							rows[i][j] = stc.getScore(i, columnName.get(j)) + "";
						}

					}

				}

				studentInfoTable.setModel(new DefaultTableModel(rows, columnName.toArray()));

				JOptionPane.showMessageDialog(null, "Calculate complete");

			}
		});

		sendEmailBtn = new JButton(new ImageIcon("send.jpg"));
		sendEmailBtn.setPreferredSize(new Dimension(200, 50));
		sendEmailBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser jf = new JFileChooser(".");
				if (jf.showOpenDialog(null) == jf.APPROVE_OPTION) {
					sec.readFile(jf.getSelectedFile(), stc);
					if (sec.isCheck()) {
						int check = JOptionPane.showConfirmDialog(null, "Do you sure to send email?");
						if (check == 0) {
							for(int i =0;i<stc.getData().size();i++) {
								sec.sendEmail(stc,i,sec.getEmail(i), columnName);
							}
							JOptionPane.showMessageDialog(null, "message send successfully");
						}

					}

				}
			}
		});

		saveBtn = new JButton(new ImageIcon("save.jpg"));
		saveBtn.setPreferredSize(new Dimension(200, 50));
		saveBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				WritingExcelMng wem = new WritingExcelMng();
				wem.readData(stc.getData());
				JFileChooser jf = new JFileChooser(".");
				if (jf.showSaveDialog(null) == jf.APPROVE_OPTION) {
					wem.writeExcel(jf.getSelectedFile().getAbsolutePath());
					JOptionPane.showMessageDialog(null, "Save complete");
				}
			}
		});

		exitBtn = new JButton(new ImageIcon("exit.jpg"));
		exitBtn.setPreferredSize(new Dimension(200, 50));
		exitBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);

			}
		});

		addBtn.setEnabled(false);
		deleteBtn.setEnabled(false);
		calculateBtn.setEnabled(false);
		sendEmailBtn.setEnabled(false);
		saveBtn.setEnabled(false);

		status.setText("Professor");
		GridLayout g = new GridLayout(8, 0);
		g.setVgap(5);
		btnPanel.setLayout(g);
		btnPanel.add(uploadBtn);
		btnPanel.add(addBtn);
		btnPanel.add(deleteBtn);
		btnPanel.add(calculateBtn);
		btnPanel.add(sendEmailBtn);
		btnPanel.add(saveBtn);
		btnPanel.add(exitBtn);

		controlPanel.add(btnPanel);

		controlPanel.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY, 1), "Control"));

		statusPanel.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY), "Status"));
		statusPanel.add(status);

		contentPane.setLayout(new BorderLayout());
		contentPane.add(statusPanel, BorderLayout.NORTH);
		contentPane.add(controlPanel);

		this.setLayout(new BorderLayout());
		this.add(tablepanel);
		this.add(contentPane, BorderLayout.EAST);

	}
}
