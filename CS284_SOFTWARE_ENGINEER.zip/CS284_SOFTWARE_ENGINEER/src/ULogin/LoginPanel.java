package ULogin;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Color;

import javax.swing.ImageIcon;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import UuploadFileAndFillScore.FillPointProFFrame;
import UuploadFileAndFillScore.FillPointTaFrame;

import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginPanel {
	private boolean check1, check2;
	private JFrame frame;
	private JTextField userField;
	private JPasswordField passwordField;
	private CheckLogin cl;
	private FillPointProFFrame fpf ;
	private FillPointTaFrame ftf;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPanel window = new LoginPanel();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public LoginPanel() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 331, 440);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		frame.setIconImage((new ImageIcon("icon.png")).getImage());
		fpf = new FillPointProFFrame();
		ftf = new  FillPointTaFrame();
	    

		cl = new CheckLogin();
		check1 = true;
		check2 = true;

		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if (cl.isUserNameAndPassWord(userField.getText(), passwordField.getText())) {
					userField.setForeground(Color.BLACK);
					frame.dispose();
					cl.setPriority(userField.getText(), passwordField.getText());
				
					if(cl.getPriority().equalsIgnoreCase("prof")) {
						fpf.setVisible(true);
					}else if(cl.getPriority().equalsIgnoreCase("ta")) {
						ftf.setVisible(true);
					}
				

				} else {

					userField.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 10));
					userField.setForeground(Color.RED);
					userField.setText("Wrong username or password");
					check1 = true;
				}
			}
		});
		btnNewButton.setIcon(new ImageIcon("Btn..jpg"));
		btnNewButton.setBounds(107, 296, 119, 43);
		frame.getContentPane().add(btnNewButton);

		userField = new JTextField();
		userField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {

				if (check1) {
					userField.setText("");
					check1 = false;
				}
				userField.setForeground(Color.BLACK);
			}
		});
		userField.setFont(new Font("Microsoft JhengHei UI Light", Font.PLAIN, 23));
		userField.setText("Username");
		userField.setBounds(62, 186, 202, 44);
		frame.getContentPane().add(userField);
		userField.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (check2) {
					passwordField.setText("");
					check2 = false;
				}
			}
		});
		passwordField.setBounds(62, 241, 202, 44);
		passwordField.setText("Password");
		frame.getContentPane().add(passwordField);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("op0.jpg"));
		label.setBounds(0, -60, 327, 518);
		frame.getContentPane().add(label);
	}
}
