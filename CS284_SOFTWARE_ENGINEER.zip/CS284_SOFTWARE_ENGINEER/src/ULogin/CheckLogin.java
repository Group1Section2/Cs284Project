package ULogin;
public class CheckLogin {
	private AccountFileMgr acm;
    private String priority =" "; 
	public CheckLogin() {
		acm = new AccountFileMgr();
		acm.readFile();
		priority = null;
	}

	public boolean isUserNameAndPassWord(String userName, String password) {
		boolean check = false;
		for (int i = 0; i < acm.size(); i++) {
			if ((userName.equals(acm.get(i).getUserName()) && password.equals(acm.get(i).getPassWord()))) {
				check = true;
			}
		}
		return check;
	}
	public void setPriority(String userName, String password) {
		 priority = acm.getPriority(userName,password);
	}
	public String getPriority(){
		return priority;
	}
	public Account search(String username, String password){
		return acm.search(username,password);
	}
}
