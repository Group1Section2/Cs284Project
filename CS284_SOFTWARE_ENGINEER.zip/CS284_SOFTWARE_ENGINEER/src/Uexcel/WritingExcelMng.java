package Uexcel;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import UuploadFileAndFillScore.StudentFileMgr;

public class WritingExcelMng {
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	Map<Integer, Object[]> data;
	StudentFileMgr database;
	Set<Integer> keyset;
	
	public WritingExcelMng(){
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("Student Data");
		data = new TreeMap<Integer, Object[]>();
		database = null;
		keyset = data.keySet();
	}
	public void readData(StudentFileMgr info){
		database = info;
		for(int i=0;i<database.getStudent().size();i++){
	    	if(i==0){
	    		ArrayList<Object> head = new ArrayList<>();
	        	head.add("Index");
	        	head.add("ID");
	        	head.add("Name");
	        	for(int j=0;j<database.get(i).getScore().size();j++){
	           		head.add(database.get(i).getScore().get(j).getExam().toString());
	           	}
	        	head.add("Grade");
	    		data.put(0, head.toArray());
	    	}
	    	ArrayList<Object> obj = new ArrayList<>();
	       	obj.add(database.get(i).getIndex());
	       	obj.add(database.get(i).getId());
	       	obj.add(database.get(i).getName());
	        	
	       	for(int j=0;j<database.get(i).getScore().size();j++){
	       		obj.add(database.get(i).getScore().get(j).getNetScore());
	       	}
	       	obj.add(database.get(i).getGrade());
	       	data.put(i+1, obj.toArray());
	    }
	}
	public void writeExcel(String fileName){
		int rownum = 0;
	    for (Integer key : keyset) 
	    {
	        Row row = sheet.createRow(rownum++);
	        Object[] objArr = data.get(key);

	        int cellnum = 0;

	        for (Object obj : objArr) 
	        {
	            Cell cell = row.createCell(cellnum++);
	            if (obj instanceof String) 
	            {
	                cell.setCellValue((String) obj);
	            }
	            else if (obj instanceof Integer) 
	            {
	                cell.setCellValue((Integer) obj);
	            }
	            else if(obj instanceof Long){
	            	String longString = (Long)obj+"";
	            	cell.setCellValue(longString);
	            }
	            else if(obj instanceof Double){
	            	cell.setCellValue((Double)obj);
	            }
	        }
	    }
	    try{ 

	        FileOutputStream out = new FileOutputStream(new File(fileName));
	        workbook.write(out);
	        out.close();
	    } 
	    catch (Exception e)
	    {
	        System.out.println(e.getMessage());
	    }    
	}
}

