package UEmail;

import java.util.ArrayList;

public class StudentEmailMgr {
	private ArrayList<StudentEmail> emailList ;
	public StudentEmailMgr() {
		emailList = new ArrayList<>();
	}
	public StudentEmail getStudentEmail(int index){ 
		return emailList.get(index);
	}
	public void add (StudentEmail s) {
		emailList.add(s);
	}
	public int size(){ 
		return emailList.size();
	}
}
