package UEmail;

public class StudentEmail {
	private String id;
	private String email;

	public StudentEmail(String id, String email) {
		super();
		this.id = id;
		this.email = email;
	}

	public String getId() {
		return id;
	}

	public String getEmail() {
		return email;
	}

}
