package UEmail;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JOptionPane;



import UuploadFileAndFillScore.StudentControl;
import UuploadFileAndFillScore.StudentFileMgr;

public class StudentEmailController {
	private StudentEmailMgr sem;
	private String id, email;
	private StudentFileMgr database;
	private int cnt;
	private boolean check;

	public StudentEmailController() {
		sem = new StudentEmailMgr();
		cnt = 0;
		check = false;
	}

	public void readFile(File file, StudentControl sct) {
		try {

			BufferedReader bf = new BufferedReader(new FileReader(file));
			BufferedReader bf2 = new BufferedReader(new FileReader(file));
			String line = "";
			cnt = 0;
			try {
				while ((line = bf.readLine()) != null) {
					StringTokenizer stk = new StringTokenizer(line, ",");
					id = stk.nextToken();
					email = stk.nextToken();
					for (int i = 0; i < sct.getData().size(); i++) {
						if (sct.getData().get(i).getId() == Long.parseLong(id)) {
							cnt++;
						}
					}
				}
				id = "";
				email = "";
				if (cnt == sct.getData().size()) {
					check = true;
					JOptionPane.showMessageDialog(null, "Your file was macth with Student's data in system");
					while ((line = bf2.readLine()) != null) {
						StringTokenizer stk = new StringTokenizer(line, ",");
						id = stk.nextToken();
						email = stk.nextToken();
						sem.add(new StudentEmail(id, email));
					}
				} else {
					check = false;
					JOptionPane.showMessageDialog(null, "Your file was not macth with Student's data in system");
				}

			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Invalid Format file\n \"ID. Email\" is correct Format");
			}
			bf.close();
			bf2.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void sendEmail(StudentControl stc,int index,String email, ArrayList<String> columnName) {
		try {
			String host = "smtp.gmail.com";
			String user = "Cancergroup12@gmail.com";
			String pass = "Cancer12";
			String from = "Cancergroup12@gmail.com";
			String subject = "Your cs284 grade dudeeeeeee!!!!";
			String messageText = "";
			boolean sessionDebug = false;

			Properties props = System.getProperties();
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.required", "true");
			Session mailSession = Session.getDefaultInstance(props, null);
			mailSession.setDebug(sessionDebug);
			Message msg = new MimeMessage(mailSession);
			msg.setFrom(new InternetAddress(from));

	
				InternetAddress[] address = { new InternetAddress(email) };
				messageText =  stc.getData().get(index).getId() + " "
						+ stc.getData().get(index).getName() + "Your Grade : "
						+ stc.getData().get(index).getGrade();
				
				msg.setRecipients(Message.RecipientType.TO, address);
				msg.setSubject(subject);
				msg.setSentDate(new Date());
				msg.setText(messageText);
		
			
				MimeBodyPart messageBodyPart1 = new MimeBodyPart();
				MimeBodyPart messageBodyPart2 = new MimeBodyPart();
				Multipart multipart = new MimeMultipart();

				// attached 1 --------------------------------------------
				// jFileChooser.showOpenDialog(null);
				String description = "Open file below here";
				messageBodyPart1.setText(description);
				File file = new File("Score.txt");
				
				BufferedWriter bf = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file),"UTF-8"));
				bf.write(messageText);
				bf.close();
				DataSource source = new FileDataSource(file);
				messageBodyPart2.setDataHandler(new DataHandler(source));
				messageBodyPart2.setFileName("Score");
				multipart.addBodyPart(messageBodyPart1);
				multipart.addBodyPart(messageBodyPart2);
			

				// ------------------------------------------------------

				msg.setContent(multipart);

			Transport transport = mailSession.getTransport("smtp");
			transport.connect(host, user, pass);
			transport.sendMessage(msg, msg.getAllRecipients());
			transport.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}
    public String getEmail(int index) {
    	return sem.getStudentEmail(index).getEmail();
    }
	public boolean isCheck() {
		return check;
	}
}
