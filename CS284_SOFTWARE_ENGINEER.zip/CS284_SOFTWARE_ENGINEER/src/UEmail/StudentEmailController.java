package UEmail;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;



import UuploadFileAndFillScore.StudentControl;
import UuploadFileAndFillScore.StudentFileMgr;

public class StudentEmailController {
	private StudentEmailMgr sem;
	private String id, email;
	private StudentFileMgr database;
	private int cnt;
	private boolean check;

	public StudentEmailController() {
		sem = new StudentEmailMgr();
		cnt = 0;
		check = false;
	}

	public void readFile(File file, StudentControl sct) {
		try {

			BufferedReader bf = new BufferedReader(new FileReader(file));
			BufferedReader bf2 = new BufferedReader(new FileReader(file));
			String line = "";
			cnt = 0;
			try {
				while ((line = bf.readLine()) != null) {
					StringTokenizer stk = new StringTokenizer(line, ",");
					id = stk.nextToken();
					email = stk.nextToken();
					for (int i = 0; i < sct.getData().size(); i++) {
						if (sct.getData().get(i).getId() == Long.parseLong(id)) {
							cnt++;
						}
					}
				}
				id = "";
				email = "";
				if (cnt == sct.getData().size()) {
					check = true;
					JOptionPane.showMessageDialog(null, "Your file was macth with Student's data in system");
					while ((line = bf2.readLine()) != null) {
						StringTokenizer stk = new StringTokenizer(line, ",");
						id = stk.nextToken();
						email = stk.nextToken();
						sem.add(new StudentEmail(id, email));
					}
				} else {
					check = false;
					JOptionPane.showMessageDialog(null, "Your file was not macth with Student's data in system");
				}

			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Invalid Format file\n \"ID. Email\" is correct Format");
			}
			bf.close();
			bf2.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void sendEmail(StudentControl stc, ArrayList<String> columnName) {
		try {
			String host = "smtp.gmail.com";
			String user = "Cancergroup12@gmail.com";
			String pass = "Cancer12";
			String from = "Cancergroup12@gmail.com";
			String subject = "à¸„à¸°à¹�à¸™à¸™à¸ªà¸­à¸š";
			String messageText = "";
			boolean sessionDebug = false;

			Properties props = System.getProperties();
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.required", "true");
			Session mailSession = Session.getDefaultInstance(props, null);
			mailSession.setDebug(sessionDebug);
			Message msg = new MimeMessage(mailSession);
			msg.setFrom(new InternetAddress(from));
			for (int i = 0; i < sem.size(); i++) {

				for(int j =0;j<stc.getData().get(i).getScore().size() ;j++) {
					InternetAddress[] address = { new InternetAddress(sem.getStudentEmail(i).getEmail().trim()) };
					messageText = stc.getData().get(i).getIndex() + " " + stc.getData().get(i).getId() + " "
							+ stc.getData().get(i).getName() + "  Score : "
							+ stc.getData().get(i).getScore().get(j).getScore() + " Net score: "
							+ stc.getData().get(i).getScore().get(j).getNetScore() + " Grade : "
							+ stc.getData().get(i).getGrade();
					msg.setRecipients(Message.RecipientType.TO, address);
					msg.setSubject(subject);
					msg.setSentDate(new Date());
					msg.setText(messageText);
				}
			}

			Transport transport = mailSession.getTransport("smtp");
			transport.connect(host, user, pass);
			transport.sendMessage(msg, msg.getAllRecipients());
			transport.close();
			JOptionPane.showMessageDialog(null, "message send successfully");
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

	public boolean isCheck() {
		return check;
	}
}
