package UuploadFileAndFillScore;
import javax.swing.JFrame;

public class FillPointProFFrame extends JFrame {
	private FillPointProFPanel fp;
	public FillPointProFFrame() {
		fp = new FillPointProFPanel();
		this.add(fp);
		this.pack();
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
}
