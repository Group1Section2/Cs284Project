package UuploadFileAndFillScore;


public interface calculateScore {
	
	public boolean setScore(double score,double maxScore);

	public double calculateScore(double score,double parameter);
	
	
}
