package UuploadFileAndFillScore;

import javax.swing.JFrame;

public class FillPointTaFrame extends JFrame {
	private FillPointTaPanel fp ;
	public FillPointTaFrame() {
		fp = new FillPointTaPanel();
		this.add(fp);
		this.pack();
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

}
