package UuploadFileAndFillScore;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;



public class FillPointProFPanel extends JPanel {

	private JButton uploadBtn, addBtn, deleteBtn, calculateBtn, saveBtn, exitBtn;
	private JFileChooser jfc;
	private File file;
	private StudentControl stc;
	private JTable studentInfoTable;
	private ArrayList<String> columnName;
	private String[][] rows;
    private JLabel status;
	public FillPointProFPanel() {

		JPanel controlPanel = new JPanel(); 
		JPanel tablepanel = new JPanel();
		JPanel btnPanel = new JPanel();
		JPanel statusPanel = new JPanel();
		JPanel contentPane = new JPanel();
		status = new JLabel();
		
	
		jfc = new JFileChooser(".");
		stc = new StudentControl();

		addBtn = new JButton("Add Exam Score");
		
	
		columnName = new ArrayList<>();
		columnName.add("Index");
		columnName.add("ID.");
		columnName.add("Name");
	
		rows = new String[0][3];

		studentInfoTable = new JTable(rows, columnName.toArray());

		JScrollPane tableScroll = new JScrollPane(studentInfoTable);
		tableScroll.setPreferredSize(new Dimension(800, 460));
		tablepanel.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY), "Untitled"));
		tablepanel.add(tableScroll);

		
		
		uploadBtn = new JButton("Upload File");
		uploadBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (jfc.showOpenDialog(null) == jfc.APPROVE_OPTION) {
					file = jfc.getSelectedFile();
					stc.readFile(file);
					tablepanel.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY), file.getName()));
					rows = new String[stc.getData().size()][columnName.size()];

					
					for (int i = 0; i < stc.getData().size(); i++) {
						for (int j = 0; j < columnName.size(); j++) {
							if (j == 0) {
								rows[i][j] = stc.getData().get(i).getIndex() + "";

							} else if (j == 1) {
								rows[i][j] = stc.getData().get(i).getId() + "";

							} else if (j == 2) {
								rows[i][j] = stc.getData().get(i).getName();

							}
						}
					}
					studentInfoTable.setModel(new DefaultTableModel(rows, columnName.toArray()));

				}

			}
		});

		addBtn = new JButton("Add Exam");
		addBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String newColumnName = JOptionPane.showInputDialog(null, "Input your column name");
				if (!stc.examContain(newColumnName)) {
					if (newColumnName != null) {
						deleteBtn.setEnabled(true);
						columnName.add(newColumnName);
						studentInfoTable.setModel(new DefaultTableModel(rows, columnName.toArray()));

						double max;
						double weight;
						while (true) {
							try {

								do {
									String parameter = JOptionPane.showInputDialog(null,
											"Input your parameter for " + newColumnName + " : max,net");
									StringTokenizer st = new StringTokenizer(parameter, ",");
									max = Double.parseDouble(st.nextToken());
									weight = Double.parseDouble(st.nextToken());
									if (max < weight) {
										JOptionPane.showMessageDialog(null, "max must over than net");
									}
								} while (max < weight);

								for (int i = 0; i < stc.getData().size(); i++) {
									stc.addExam(i, newColumnName, max, weight);
								
								}
								break;
							} catch (NoSuchElementException e1) {
								JOptionPane.showMessageDialog(null, "Please input max and net");
							} catch (NumberFormatException e2) {
								JOptionPane.showMessageDialog(null, "Please use , to split max and net");
							}
						}

					}
				} else {
					JOptionPane.showMessageDialog(null, "Can't add same exam");
				}
			}
		});

		deleteBtn = new JButton("Delete Exam");
		deleteBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				for(String s :columnName){
					if(s.equals("Grade Score")){
						columnName.remove(columnName.indexOf(s));
						break;
					}
				}
				
				String deleteName = JOptionPane.showInputDialog(null, "Input your delete exam");
				for (int i = 3; i < columnName.size(); i++) {
					if (columnName.get(i).contentEquals(deleteName)) {
						columnName.remove(i);
					}
				}
				for (int i = 0; i < stc.getData().size(); i++) {
					stc.removeExam(i, deleteName);
					// stc.getData().get(i).print();
				}
				studentInfoTable.setModel(new DefaultTableModel(rows, columnName.toArray()));


			}
		});


		calculateBtn = new JButton("Calculate");
		calculateBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				Calculate cal = new Calculate();
				
				for (int i = 0; i < stc.getData().size(); i++) {
					for (int j = 0; j < columnName.size(); j++) {
						if (stc.examContain(columnName.get(j))) {
							if (studentInfoTable.getValueAt(i, j) == null) {
								studentInfoTable.setValueAt(0.0, i, j);
							} else if (!(cal.setScore(Double.parseDouble(studentInfoTable.getValueAt(i, j).toString()),
									stc.getMax(columnName.get(j))))) {
								studentInfoTable.setValueAt(0.0, i, j);
							}
							stc.updateScore(i, columnName.get(j),
									Double.parseDouble(studentInfoTable.getValueAt(i, j).toString()));
							stc.setNetScore(i, columnName.get(j), cal.calculateScore(stc.getScore(i, columnName.get(j)),
									stc.getParameter(columnName.get(j))));
						}
					}
				}
				
				for(String s :columnName){
					if(s.equals("Grade Score")){
						columnName.remove(columnName.indexOf(s));
						break;
					}
				}
				columnName.add("Grade Score");
				rows = new String[stc.getData().size()][columnName.size()];
				
				for (int i = 0; i < stc.getData().size(); i++) {
					for (int j = 0; j < columnName.size(); j++) {
						if (j == 0) {
							rows[i][j] = stc.getData().get(i).getIndex() + "";

						} else if (j == 1) {
							rows[i][j] = stc.getData().get(i).getId() + "";

						} else if (j == 2) {
							rows[i][j] = stc.getData().get(i).getName();

						} else if (j == columnName.size() - 1) {
							rows[i][j] = stc.getData().get(i).getGradeScore() + "";
						} else {
							rows[i][j] = stc.getScore(i, columnName.get(j)) + "";
						}

					}

				}
				
				studentInfoTable.setModel(new DefaultTableModel(rows, columnName.toArray()));

				JOptionPane.showMessageDialog(null, "Calculate complete");

			}
		});
		saveBtn = new JButton("Save");
		saveBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				FileOutputStream fw;
				String line = "";
				try {
					if (jfc.showSaveDialog(null) == jfc.APPROVE_OPTION) {

						BufferedWriter bf = new BufferedWriter(
								new OutputStreamWriter(new FileOutputStream(jfc.getSelectedFile()), "UTF-8"));

						for (int i = 0; i < stc.getData().size(); i++) {
							for (int j = 0; j < columnName.size(); j++) {
								if (j == 0) {
									line = line + " " + studentInfoTable.getValueAt(i, j);

								} else if (j == 1) {
									line = line + " " + studentInfoTable.getValueAt(i, j);

								} else if (j == 2) {
									line = line + " " + studentInfoTable.getValueAt(i, j);

								}

							}
							

						}
						bf.write(line);
						bf.newLine();

						JOptionPane.showMessageDialog(null, "Save complete");
						bf.close();
					}

				} catch (IndexOutOfBoundsException e3) {
					JOptionPane.showMessageDialog(null, "please update the data ");
				} catch (FileNotFoundException e2) {
					JOptionPane.showMessageDialog(null, "File not Found");
				} catch (IOException e1) {

					e1.printStackTrace();
				}

			}
		});

		exitBtn = new JButton("Exit");
		exitBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);

			}
		});

		addBtn.setEnabled(false);
		deleteBtn.setEnabled(false);
		// updateBtn.setEnabled(false);
		calculateBtn.setEnabled(false);
		saveBtn.setEnabled(false);

		status.setText("Professor");
		GridLayout g = new GridLayout(7, 0);
		g.setVgap(5);
		btnPanel.setLayout(g);
		btnPanel.add(uploadBtn);
		btnPanel.add(addBtn);
		btnPanel.add(deleteBtn);
		btnPanel.add(calculateBtn);
		btnPanel.add(saveBtn);
		btnPanel.add(exitBtn);
		
	
		controlPanel.add(btnPanel);
		
		controlPanel.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY, 1), "Control"));
	

		statusPanel.setBorder(new TitledBorder(new LineBorder(Color.LIGHT_GRAY),"Status"));
		statusPanel.add(status);
		
		contentPane.setLayout(new BorderLayout());
		contentPane.add(statusPanel,BorderLayout.NORTH);
		contentPane.add(controlPanel);
		
		this.setLayout(new BorderLayout());
		this.add(tablepanel);
		this.add(contentPane, BorderLayout.EAST);

	}

//	public void setupByPriority(JButton btn){
//		MainProgram m = new MainProgram();
//		if(m.getAccount().getPriority().equals(PROF)){
//			if(btn.equals(uploadBtn)){
//				addBtn.setEnabled(true);
//				
//			}else if(btn.equals(addBtn)){
//				deleteBtn.setEnabled(true);
//				calculateBtn.setEnabled(true);
//			}else if(btn.equals(deleteBtn)){
//				if (columnName.size() <= 3) {
//					calculateBtn.setEnabled(false);
//					deleteBtn.setEnabled(false);
//				}
//			}
//		}else if(m.getAccount().getPriority().equals(TA)){
//			if(btn.equals(uploadBtn)){
//				addBtn.setEnabled(true);
//				
//			}else if(btn.equals(addBtn)){
//				deleteBtn.setEnabled(true);
//				calculateBtn.setEnabled(true);
//			}else if(btn.equals(deleteBtn)){
//				if (columnName.size() <= 3) {
//					calculateBtn.setEnabled(false);
//					deleteBtn.setEnabled(false);
//				}
//			}
//		}
//	}
}
