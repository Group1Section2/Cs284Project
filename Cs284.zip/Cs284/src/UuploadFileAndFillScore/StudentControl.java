package UuploadFileAndFillScore;
import java.io.File;

public class StudentControl {
	StudentFileMgr stm;
	
	public StudentControl() {
		stm = new StudentFileMgr();
	}
	public void readFile(File file) {
		stm.readFile(file);
	}
	public StudentFileMgr getData() {
		return stm;
	}
	
	public void addExam(int index,String exam,double max,double weight){
		stm.get(index).addScore(exam,max,weight);
	}
	public void removeExam(int index,String exam){
		stm.get(index).removeScore(exam);
	}
	public boolean examContain(String exam){
		return stm.get(0).examContain(exam);
	}
	public double getMax(String exam){
		return stm.get(0).getMax(exam);
	}
	public double getParameter(String exam){
		return stm.get(0).getParameter(exam);
	}
	public void setNetScore(int index,String exam,double netScore){
		stm.get(index).setNetScore(exam, netScore);
	}
	public double getScore(int index,String exam){
		return stm.get(index).getScore(exam);
	}
	public double getGradeScore(int index){
		return stm.get(index).getGradeScore();
	}
	
	
	
	public void updateScore(int index,String exam,double score){
		stm.get(index).updateScore(exam,score);
	}
}
