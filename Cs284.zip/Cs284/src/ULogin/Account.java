package ULogin;

public class Account {
	private String userName,passWord,priority;

	public Account(String userName,String passWord,String priority) {
		this.userName = userName;
		this.passWord = passWord;
		this.priority = priority;
	}
	public String getUserName() {
		return userName;
	}

	public String getPassWord() {
		return passWord;
	}
	public String getPriority() {
		return priority;
	}

	
}
